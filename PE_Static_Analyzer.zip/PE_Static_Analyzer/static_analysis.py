import os
import sys
import math
from datetime import datetime

try:
	import pefile
except ImportError:
	print("Unable to import pefile module")
	sys.exit()

import wincert.wintrust as wintrust

SECT_CHAR_FLAGS = {
			'Has Code' :0x00000020, 
			'Initialized data' :0x00000040, 
			'Uninitialized data' :0x00000080, 
			'Cannot be cached' :0x04000000, 
			'Not pageable' :0x08000000, 
			'Shared' :0x10000000, 
			'Executable' :0x20000000, 
			'Readable' :0x40000000, 
			'Writable' :0x80000000	
}

class PEDetails:

	ATTRS_DOS_HDR 	= "e_magic, e_lfanew"
	ATTRS_FILE_HDR 	= "Machine, NumberOfSections, NumberOfSymbols, PointerToSymbolTable, SizeOfOptionalHeader, TimeDateStamp"
	ATTRS_OPP_HDR 	= "ImageBase, LoaderFlags, Magic, MajorImageVersion, MajorLinkerVersion, MajorOperatingSystemVersion, MajorSubsystemVersion, MinorImageVersion, MinorLinkerVersion, MinorOperatingSystemVersion, MinorSubsystemVersion, NumberOfRvaAndSizes, Reserved1, SectionAlignment, SizeOfCode, SizeOfHeaders, SizeOfHeapCommit, SizeOfHeapReserve, SizeOfImage, SizeOfInitializedData, SizeOfStackCommit, SizeOfStackReserve, SizeOfUninitializedData, Subsystem"
	ATTRS_SECTION 	= "Name, Misc_VirtualSize, VirtualAddress, SizeOfRawData, PointerToRawData, PointerToRelocations, PointerToLinenumbers, NumberOfRelocations, NumberOfLinenumbers"


	MAIN_ENCODING = "utf-8"
	def __init__(self, file_path, fast=True):
		"""Summary
		
		Args:
			file_path (TYPE): Description
			fast (bool, optional): Description
		"""
		self.file_path = file_path
		self.pe = pefile.PE(file_path)
	

	def _get_file_buffer(self):
		try:
			with open(self.file_path, "rb") as f:
				buf = f.read()
			return buf
		except Exception as e:
			return None

	def _get_file_size(self):
		# try:
		return os.path.getsize(self.file_path)
		# except Exception as e:
		# 	return None



	def _get_dos_header_attrs(self):
		"""Summary
		
		Returns:
			TYPE: Description
		"""
		# Returns important fields like e_magic and e_lfanew
		return {attr:getattr(self.pe.DOS_HEADER, attr) for attr in self.ATTRS_DOS_HDR.split(", ")}

	def _get_file_header_attrs(self):
		"""Summary
		
		Returns:
			TYPE: Description
		"""
		return {attr:getattr(self.pe.FILE_HEADER, attr) for attr in self.ATTRS_FILE_HDR.split(", ")}

	def _get_opp_header_attrs(self):
		"""Summary
		
		Returns:
			TYPE: Description
		"""
		return {attr:getattr(self.pe.OPTIONAL_HEADER, attr) for attr in self.ATTRS_OPP_HDR.split(", ")}
		
	def get_opptional_header_checksum(self):
		"""Summary
		
		Returns:
			TYPE: Description
		"""
		return self.pe.OPTIONAL_HEADER.CheckSum
	
	def recalculate_checksum(self):
		"""Summary
		
		Returns:
			TYPE: Description
		"""
		return self.pe.generate_checksum()
	
	def get_compile_time(self):
		try:
			return self.pe.FILE_HEADER.TimeDateStamp
		except Exception as e:
			return None

	def get_sections_details(self, char_type="Any"):
		"""Get details of interest from PE Sections
		
		Returns:
			dict: Name with entopy and characteristics
		
		Args:
			char_type (str, optional): Description
		
		Raises:
			e: Description
		"""
		try:
			if (char_type == "Any"):
				return [{attr:getattr(sect, attr) for attr in self.ATTRS_SECTION.split(", ")}for sect in self.pe.sections]
			else:
				return [{attr:getattr(sect, attr) for attr in self.ATTRS_SECTION.split(", ")}for sect in self.pe.sections if (sect.Characteristics & SECT_CHAR_FLAGS[char_type] == SECT_CHAR_FLAGS[char_type])]
		except Exception as e:
			return None


	
	
	def get_imported_details(self):
		"""Summary
		
		Returns:
			TYPE: Description
		"""
		return {entry.dll.decode('utf-8'):[api.name for api in entry.imports] for entry in self.pe.DIRECTORY_ENTRY_IMPORT}
		# for entry in self.pe.DIRECTORY_ENTRY_IMPORT:
		# 	for x in entry.imports:
	def get_imported_functions(self):
		try:
			apis = []
			for entry in self.pe.DIRECTORY_ENTRY_IMPORT:
				for x in entry.imports:
					apis.append(x.name)
			return apis
		except Exception as e:
			return None
		

	def get_export_directory_details(self):
		try:
			return {export.address:export.name.decode('utf-8') for export in self.pe.DIRECTORY_ENTRY_EXPORT.symbols}
		except AttributeError:
			return None
	
	def get_debug_directory_details(self):

		try:
			for d in self.pe.DIRECTORY_ENTRY_DEBUG:
				print(d.entry)

		except Exception as e:
			return None

	


class HeuristicsAnalyser:

	NORMAL_ENTRY_SECTIONS = ['.text', '.code', 'CODE', 'INIT', 'PAGE']

	SIGNATURES = {
			"MZ" : b"\x4D\x5A", # will be at 0x0000
			"PE" : b"\x50\x45\x00\x00",  #will be at 0x00F8 & 0x100
			"OPP": [b"\x0B\x01", b"\x0B\x02", b"\x07\x01"] #will be at offset 0x110 & 0x118

	}

	SIG_OFFSETS = {
			"PE" : [0xF8, 0x100],
			"OPP": [0x110, 0x118]
	}

	def __init__(self, pe_object: PEDetails):
		self.score = 0
		self.pe_object = pe_object
		
	def has_multiple_pe_header(self):
		# with open (self.pe_object.file_name)
		# print(self.pe_object.file_path)
		mz_pos = -1 
		with open(self.pe_object.file_path, "rb") as f:
			buf = f.read()
			# print(self.SIGNATURES["MZ"])

		buffer_size = len(buf)
		found_coordinates = []
		for i in range(buffer_size):
			
			if (buf[i:i+2] == self.SIGNATURES["MZ"] and (i + 0x118) <= buffer_size):

				pe_off1 = i+self.SIG_OFFSETS["PE"][0]
				pe_off2 = i+self.SIG_OFFSETS["PE"][1]
				opp_off1 = i+self.SIG_OFFSETS["OPP"][0]
				opp_off2 = i+self.SIG_OFFSETS["OPP"][1]

				if (buf[pe_off1:pe_off1+4] == self.SIGNATURES["PE"] and buf[opp_off1:opp_off1+2] in self.SIGNATURES["OPP"]):
					found_coordinates.append({"MZ":i, "PE":pe_off1, "OPP":opp_off1})
				elif (buf[pe_off2:pe_off2+4] == self.SIGNATURES["PE"] and buf[opp_off2:opp_off2+2] in self.SIGNATURES["OPP"]):
					found_coordinates.append({"MZ":i, "PE":pe_off2, "OPP":opp_off2})

					

	def has_multiple_executable_sections(self):
		return len(self.pe_object.get_sections_details("Executable")) > 1

	def check_entry_point(self):
		"""Check which section or location
			Optional Header's EOP jumps to
		
		Args:
			pe_object (PEDetails): PEDetails object
		
		Returns:
			(int, str, int, int): Returns in (eop, SectName, SectionIndex, characteristics)
							 -1 Indicates not within any sections
		"""
		name = ""; position = 0; entry = self.pe_object.pe.OPTIONAL_HEADER.AddressOfEntryPoint
		for sect in self.pe_object.pe.sections:
			if (sect.VirtualAddress <= entry < (sect.VirtualAddress+sect.Misc_VirtualSize)):
				return (entry, sect.Name.decode("utf-8").replace("\x00", ""), position, sect.Characteristics)
			else:
				position += 1
		return (entry, "Out", -1, 00000000)

	def entry_section_not_common(self):
		try:
			return self.check_entry_point()[1] not in self.NORMAL_ENTRY_SECTIONS
		except Exception as e:
			return None

	def entry_point_not_executable(self):
		try:
			return not self.check_entry_point()[3] & SECT_CHAR_FLAGS["Executable"] == SECT_CHAR_FLAGS["Executable"]
		except Exception as e:
			return None

	def has_duplicated_section_names(self):
		section_names = [S['Name'].decode('utf-8').replace('\x00', '') for S in self.pe_object.get_sections_details()]
		return any(section_names.count(name) > 1 for name in section_names)

	def verify_checksum(self):
		""" Evaluates if the recalculation checksum 
			is consistent with the checksum value 
			in optional header
		
		Returns:
			bool: True if recalcuated checksum is consistent
		
		Args:
			pe_object (PEDetails): Description
		"""
		return True if (self.pe_object.get_opptional_header_checksum() == self.pe_object.recalculate_checksum()) else False

	def has_consistent_size_of_code(self):
		""" Recalculates size of code and
			comepares with Optional header
			SizeOfCode value
		
		Args:
			pe_object (PEDetails): PEDetails object of executable
		
		Returns:
			TYPE: Description
		"""
		try:
			total_code  = sum(x["SizeOfRawData"] for x in self.pe_object.get_sections_details("Has Code"))
			return True if (self.pe_object._get_opp_header_attrs()["SizeOfCode"] == total_code) else False
		except Exception as e:
			return None

	def has_debug_directory(self):
		""" Malwares usually do not have debug
			directory as it contains valueable
			information like time and date
		
		Args:
			pe_object (PEDetails): Description
		
		Returns:
			TYPE: Description
		"""
		return hasattr(self.pe_object.pe, "DIRECTORY_ENTRY_DEBUG")
	
	def sections_bigger_than_file(self):
		try:
			return sum(S['SizeOfRawData']for S in self.pe_object.get_sections_details()) > self.pe_object._get_file_size()
		except Exception as e:
			return None

	def run(self):
		pass

class EntropyAnalysis:
	
	THLD_ENCRYPTED 	= lambda self, e: bool(e > 7.174)
	THLD_PACKED 	= lambda self, e: bool(6.677 < e < 6.926)
	THLD_NATIVE 	= lambda self, e: bool(4.941 < e < 5.258)
	THLD_PLAIN_TXT 	= lambda self, e: bool(4.066 < e < 4.629)

	def __init__(self, pe_object: PEDetails):
		self.pe_object = pe_object

	def _evaluate_entropy(self, buff):
		i_array = [0 for _ in range(256)]

		db_entropy = 0.0; db_prob = 0.0
		for i in range(len(buff)):
			i_array[int(buff[i])] += 1

		for i in range(256):
			if i_array[i] != 0:
				db_prob = i_array[i] / len(buff)
				db_entropy -= db_prob * math.log(db_prob, 2)

		return db_entropy

	def evaluate_entropy_details(self):

		buf = self.pe_object._get_file_buffer()
		if buf is not None:
			details = []
			try:
				details = [{sect['Name'].decode('utf-8').replace('\x00',''):round(self._evaluate_entropy(buf[sect['PointerToRawData']:sect['PointerToRawData']+sect['SizeOfRawData']]),4)} for sect in self.pe_object.get_sections_details()]
				details.insert(0,{"File": round(self._evaluate_entropy(buf),4)})
				return details
			except Exception as e:
				return None
		return None

	def run(self, x):
		print("hi)")
		
		print(self.THLD_PLAIN_TXT(x))

		
if __name__ == '__main__':
	obj = PEDetails("c:\\users\\user\\desktop\\1234.exe")

	heuristics = HeuristicsAnalyser(obj)
	heuristics.has_multiple_pe_header()

	ent = EntropyAnalysis(obj)
	for item in ent.evaluate_entropy_details():
		print(item)
	ent.run(3)



